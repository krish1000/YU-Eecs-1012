/* Task6.js - Add your Java Script Code Here */
