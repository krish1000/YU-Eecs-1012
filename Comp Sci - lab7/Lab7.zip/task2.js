/* Lab 6 - Task 2  */
 window.onload = function() {

  /* Please have a look at the HTML file for the ids of the input elements */
  /* add in your event handlers here */
  /* you are highly encourage to look at the lecture notes and code on JS and Forms */

}
