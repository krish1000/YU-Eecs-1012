/* Lab 6, Task 2.  Use the prototype library */
