/* Lab 6 - Task 3.  This is related to DOM (not Events), but you can
   still use the prototype library */
