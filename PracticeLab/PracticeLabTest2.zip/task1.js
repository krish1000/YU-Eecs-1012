/* EECS1012 - Practice Lab Test #2 */
 window.onload = function() {

}
