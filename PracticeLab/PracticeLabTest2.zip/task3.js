/* Practice Lab Test #2, Task 3  */
/* EECS1012 - York University  */

/* write your code here */
