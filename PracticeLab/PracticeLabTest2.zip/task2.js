/* Practice Lab Test #2, Task 2  (version 1)*/
/* EECS1012 - York University  */

/* write your code here */
