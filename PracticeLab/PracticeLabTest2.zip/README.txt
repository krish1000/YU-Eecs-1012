PLEASE READ BEFORE STARTING
--------------------------
Try to do the lab without looking at the solution.
You will be provided cheatsheets for JavaScript and HTML + Forms (see in ZIP file).
These cheatsheets will be made available to you during the labtest, just like we did for lab test 1.

SOLUTIONS
---------
In the solutions directory, there are solutions to all tasks.  Remember, there are multiple ways to solve problems in programming, so these represents one way to do it.  

For task2.js, you have been provided three different solutions.  All are valid and would be worth 100% on the lab test.  

Task1 is related to the JS+Forms, so you will need to review the course notes to help you with this task.  The other tasks are related to labs 4, 5, 6, and 7.