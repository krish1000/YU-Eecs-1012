/* Practice Lab Test #2, Task 4 */
/* EECS1012 - York University  */

/* write your code here */
/* Array of image names is aleady provided for you */
var images=["01.png", "02.png", "03.png", "04.png", "05.png", "06.png", "07.png", "08.png"];
